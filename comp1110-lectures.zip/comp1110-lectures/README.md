The code developed during the lectures.
