package comp1110.lectures.J02;

public class BasicImperative {
    public static void main(String[] args) {
        int i = 0;
        System.out.println(i);
        i = i + 1;
        System.out.println(i);
        i = 200;
        System.out.println(i);
        if (i > 300) {
            System.out.println("Greater than 300");
        }
    }
}
