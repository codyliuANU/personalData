package comp1110.lectures.O04;

public class Robot implements Greeter {
    public void greet() {
        System.out.println("010101101");
    }
}
