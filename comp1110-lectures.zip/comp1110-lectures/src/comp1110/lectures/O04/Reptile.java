package comp1110.lectures.O04;

public class Reptile extends Animal {
    public Reptile(String name) {
        super(name);
    }
}
