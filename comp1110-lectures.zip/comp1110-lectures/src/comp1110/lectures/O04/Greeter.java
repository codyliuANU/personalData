package comp1110.lectures.O04;

interface Greeter {
    void greet();
}
