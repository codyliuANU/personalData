package comp1110.lectures.O04;

public class Snake extends Reptile {
    public Snake(String name) {
        super(name);
    }

    public void biteSomeone() {
        System.out.println("Ouch!");
    }
}
