package comp1110.lectures.A01;

import java.util.Arrays;

public class ArrayList<T> implements List<T> {
    // Hack to work around limitation of Generics with Arrays
    // Don't do this unless you know what you're doing
    private final int DEFAULT_SIZE = 2;
    private final int GROWTH_FACTOR = 2;

    private T[] values = (T[]) new Object[DEFAULT_SIZE];
    private int size = 0;

    @Override
    public void add(T value) {
        if (values.length == size) {
            T[] temp = (T[]) new Object[values.length * GROWTH_FACTOR];
            for (int i = 0; i < values.length;i++){
                temp[i] = values[i];
            }
            temp[size++] = value;
            values = temp;
        } else {
            values[size++] = value;
        }
    }

    @Override
    public T get(int index) {
        if (index >= size) throw new IndexOutOfBoundsException();
        return values[index];
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public T remove(int index) {
        if (index >= size) throw new IndexOutOfBoundsException();
        T rtn = values[index];
        for (int i = index; i < size; i++){
            values[i] = values[i+1];
        }
        size--;
        return rtn;
    }


    @Override
    public void reverse() {
        for (int i = 0; i < size/2;i++){
            T tmp = values[i];
            values[i] = values[size-1-i];
            values[size-1-i] = tmp;
        }
    }
}
