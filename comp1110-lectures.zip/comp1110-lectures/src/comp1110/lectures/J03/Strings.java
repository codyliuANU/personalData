package comp1110.lectures.J03;

public class Strings {
    public static void main(String[] args) {
        String x = "Hello";
        String y = "World";
        System.out.println(x + " " + y);
    }
}
