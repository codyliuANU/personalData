package comp1110.lectures.J03;

public class Integers {
    public static void main(String[] args) {
        int a = 0;
        a = 333_333;
        int b = Integer.parseInt("132");
        System.out.println(b + 5);
    }
}
