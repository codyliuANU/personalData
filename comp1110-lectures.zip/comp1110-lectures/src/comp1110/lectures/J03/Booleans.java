package comp1110.lectures.J03;

public class Booleans {
    public static void main(String[] args) {
        boolean a = true;
        System.out.println("a is " + a);
        boolean b = false;
        System.out.println("b is " + b);
        String c = "TruE";
        System.out.println("c is " + Boolean.parseBoolean(c));
    }
}
