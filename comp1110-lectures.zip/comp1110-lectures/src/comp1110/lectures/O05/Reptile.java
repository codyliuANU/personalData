package comp1110.lectures.O05;

public abstract class Reptile extends Animal {
    public Reptile(String name) {
        super(name);
    }

    public abstract void lick();
}
