package comp1110.lectures.O05;

public class Robot implements Greeter {
    public void greet() {
        System.out.println("010101101");
    }
}
