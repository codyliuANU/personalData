package comp1110.lectures.O05;

interface Greeter {
    void greet();
}
