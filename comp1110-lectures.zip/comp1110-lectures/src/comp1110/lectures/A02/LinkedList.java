package comp1110.lectures.A02;

import comp1110.lectures.A01.List;

public class LinkedList<T> implements List<T> {
    private class Node {
        Node next;
        T value;

        public Node(T value,Node next) {
            this.value = value;
        }
    }
    private Node start;
    private Node end;
    private int size;

    public LinkedList() {
    }

    @Override
    public void add(T value) {
        if (end == null) end = new Node(value,null);

    }

    @Override
    public T get(int index) {
        return null;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public T remove(int index) {
        return null;
    }

    @Override
    public void reverse() {

    }
}
