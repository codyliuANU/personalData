package comp1110.lectures.O03;

public interface Toxic {
    boolean isLethalToHumans();
}
