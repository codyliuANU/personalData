package comp1110.lectures.O03;

public class Chocolate implements Toxic {
    @Override
    public boolean isLethalToHumans() {
        return false;
    }
}
