package comp1110.lectures.O03;

public class HydrogenCyanide implements Toxic {
    @Override
    public boolean isLethalToHumans() {
        return true;
    }
}
