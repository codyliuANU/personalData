package comp1110.lectures.O03;

public class BrownSnake implements Toxic {
    @Override
    public boolean isLethalToHumans() {
        return true;
    }
}
