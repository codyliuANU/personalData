package comp1110.lectures.J01;

import java.util.Scanner;

public class IOTest {
    public int f(int a){
        return a + 1;
    }
}
