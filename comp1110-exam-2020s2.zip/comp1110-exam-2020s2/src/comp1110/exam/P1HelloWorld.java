package comp1110.exam;

import java.util.Arrays;

/*
 * This is a PRACTICE question.
 *
 * It is NOT worth any marks.
 *
 * You should complete this question and test your answer to check that your
 * setup is configured correctly and the CI is correctly working.
 */
public class P1HelloWorld {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    String input = "hi! hi ! hi";
    String[] temp = input.split(" ");
    for (int i = 0; i < temp.length; i++){
      if (temp[i].endsWith("!") &&
              temp[i].length() >= 2 &&
              temp[i].length() <= 21){
        for (char c : temp[i].toCharArray()){
          if (!((c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c == '!')){
            break;
          }
          String capitalized = temp[i].toUpperCase();
          temp[i] = capitalized;
        }
      }
    }
    String output = "";
    for (String s : temp){
      output += " "+s;
    }
    output = output.substring(1);

    System.out.println(output);
    // FIXME print out "Hello world!"
  }
}
