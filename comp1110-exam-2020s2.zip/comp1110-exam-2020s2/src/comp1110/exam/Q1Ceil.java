package comp1110.exam;

import java.util.Arrays;

/**
 * COMP1110 Final Exam, Question 1.1
 *
 * 5 Marks
 */
public class Q1Ceil {
    /**
     * Given an array of integers and a special value ceil,
     * return the largest value in the array that is less than
     * ceil.
     * {3,6,8,4,9} 7 -> 6
     * |3 - 7| = 4, |6-7| = 1, , |4-7|=3,
     * int temp = 绝对值, val = temp所对应的最靠近ceil且不超过ceil的数字
     * 对于in列表中的每个数字i，如果i > ceil直接下一个。否则|i-ceil| < temp , temp = |i-ceil|
     * (1) temp = 9999, val = 8, i = 3, ceil = 7, i < ceil, |i-ceil| = 4 < temp, temp = 4
     * (2) temp 4, val = 3, i = 6, ceil 7, i < ceil, |i-ceil| = 1 < temp, temp = 1
     * (3) temp 1, val = 6, i = 8 > ceil 直接下一个
     * (4) temp 1, val = 6, i = 4 < ceil, |i-ceil| = 3 > temp
     * (5) temp 1, val = 6, i = 9 ....
     * return val
     * If there is no value in the array that is less than
     * ceil, return (ceil+1).
     *
     * @param in    An array of integers
     * @param ceil a target value to search for in the array
     * @return the largest value in the array that is smaller than ceil,
     * or ceil+1 if there is no such value
     */
    public static int findLess(int[] in, int ceil) {
        /*
        Do not sort the input array since it'll use O(n log n),
        Direct Comparison only costs O(n) time.
         */
        int currentDiff = Integer.MAX_VALUE;
        int currentVal = ceil + 1;
        for (int i = 0; i < in.length; i++){
            if (in[i] < ceil && Math.abs(in[i] - ceil) < currentDiff){
                currentDiff = Math.abs(in[i] -ceil);
                currentVal = in[i];
            }
        }
        return currentVal; // FIXME complete this method
    }
}
