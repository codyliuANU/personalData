package comp1110.exam;

// Universe (U)
// int(Integer), String = char[]
// String x = "abc" =-> char[] {'a','b','c'}
// boolean : true, false
// char: 'a','b','c','1','9',.....
// ENUM
public class Person {
    int age;
    Gender gender; // Gender:{male,female}
    String name;
    String address;

    Person(int age, Gender gender, String name, String address){
        this.age = age;
        this.gender = gender;
        this.name = name;
        this.address = address;
    }

    public static void main(String[] args) {
        Person p1 = new Person(20,Gender.male,"Daivd","City");
        Person p2 = new Person(18,Gender.female,"Alice","Woden");

        int a = p1.age;
        int b = p2.age;
        String c = p1.name;
        String d = p2.name;
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
    }
}
