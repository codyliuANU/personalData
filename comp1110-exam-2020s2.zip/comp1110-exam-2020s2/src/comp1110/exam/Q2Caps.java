package comp1110.exam;

import java.io.*;
import java.util.LinkedList;
import java.util.List;

/**
 * COMP1110 Final Exam, Question 2
 *
 * 5 Marks
 */
public class Q2Caps {

  /**
   *
   * Q2 Part I (2 marks)
   *
   * Open the specified input file.  If the caps boolean is false, simply
   * copy all bytes of the input file to the specified output file.  Part II
   * covers the case where the caps boolean is true.
   *
   *
   * Q2 Part II (3 marks)
   *
   * Open the specified input file.  If the caps boolean is true then copy all
   * bytes of the input file directly to the output file, except any word of
   * twenty characters or less that is immediately followed by an exclamation
   * mark ('!').  Such words should be converted to all caps before copied to
   * the output file.  Words longer than 20 characters are copied directly,
   * without capitalizing.
   *
   * A word is defined as a sequence of alphabetical characters ('a' .. 'z' and
   * 'A' .. 'Z') preceded and followed by a non-alphabetical character.
   *
   * Examples (input file contents on left, output on right):
   *  "hi" -> "hi"
   *  "hi!" -> "HI!"
   *  "hi !" -> "hi !"
   *  "Hi there!" -> "Hi THERE!"
   *  "6hi!  Foo" -> "6HI!  Foo"
   *  "6hi4!  Foo" -> "6hi4!  Foo"
   *  "super!" -> "SUPER!"
   *  "supercalifragilisticexpialidocious!" -> "supercalifragilisticexpialidocious!"
   *
   * @param input The name of the input file
   * @param output The name of the output file
   * @param caps if true, capitalize words 20 characters or less if they
   *             are followed by an exclamation mark.
   */
  public static void capitalize(String input, String output, boolean caps){
    try{
      //考试的时候记忆FileReader和FileWriter的用法就行，不需要考虑其他的，
      // 并且注意一定要写在try，catch，finally（可有）的组合里
      FileReader fileReader = new FileReader(input);
      //注意只有BufferedReader可以一整行的读，其他的都只能读byte且以int形式存储。
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      String lines = "";
      String line;
      // 一行一行读取文件，然后加入到lines里，以String格式存储
      while((line = bufferedReader.readLine()) != null){
        lines += line + "\n";
      }
      // 如果读取的文件不是空的，要把最后一个换行符drop掉，要在这里多写一步
      if (lines.length() != 0){
        lines = lines.substring(0,lines.length()-1);
      }
      fileReader.close();

      //输出到文件的String命名为out
      String out = "";
      //如果需要进行强制大写
      if (caps){
        //以空格为分割界线，分割成一个个独立的单词。
        String[] temp = lines.split(" ");
        for (int i = 0; i < temp.length; i++){
          //大写的条件，末尾以！结尾，且！前面一位必须是字母，且之前的单词长度（不含空格）不能超过20.
          if (temp[i].endsWith("!") &&
                  temp[i].length() >= 2 &&
                  temp[i].length() <= 21){
            for (char c : temp[i].toCharArray()){
              if (!((c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c == '!')){
                break;
              }
              String capitalized = temp[i].toUpperCase();
              temp[i] = capitalized;
            }
          }
        }
        //将temp（即根据“ ”拆解后的单词合并到output的String里）
        for (String s : temp){
          out += " "+s; //concat的用法和+=是一样的，使用+=更简洁
        }
        //注意每次for循环out都要先加一个空格，
        // 但是一个句子第一个字符不可能是空格开头，所以要删除掉，
        // 使用substring方法保留第一位和之后的所有字符
        out = out.substring(1);
      } else {
        out = lines;
      }
      //写文件，FileWrite是一个最简单的写法，考试时候没时间去思考Stream还是Buffer的区别了。
      FileWriter fileWriter = new FileWriter(output);
      fileWriter.write(out);
      fileWriter.close();
    } catch (IOException ignored){

    }
    // FIXME complete this method
  }


}
