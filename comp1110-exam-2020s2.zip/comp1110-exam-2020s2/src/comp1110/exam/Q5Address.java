package comp1110.exam;

import java.util.Objects;
import java.util.Random;

/**
 * COMP1110 Final Exam, Question 5
 *
 * 5 Marks
 *
 * This class represents a street address within the Australian Capital Territory,
 * for example "108 North Road 2601".
 */
public class Q5Address {
    /**
     * The street number of the address (must be greater than zero) e.g. 108.
     */
    int streetNumber;

    /**
     * The street name is a string of ASCII characters e.g. "North Road"
     */
    String streetName;

    /**
     * The postcode is a number from 0 to 9999.
     */
    int postCode;

    public Q5Address(int streetNumber, String streetName, int postCode) {
        if (streetName == null) throw new IllegalArgumentException("Street name may not be null!");
        this.streetNumber = streetNumber;
        this.streetName = streetName;
        this.postCode = postCode;
    }

    /**
     * @return a hash code value for this object.
     * In implementing this method, you may *not* use the default Java
     * implementations in Object.hashCode() or Objects.hash().
     * @see Object#hashCode()
     */
    @Override
    public int hashCode() {
        // FIXME complete this method
        int h = 0;
        String a = String.valueOf(streetNumber);
        String c = String.valueOf(this.postCode);
        String f = a + " " + streetName + " "+ c;
        for (int i = 0; i < f.length();i++){
            h += f.charAt(i) * i;
            //这里注意如果不乘以位置index i会出现 “10 Carina St 15” == “15 Carina St 10”的情况
        }
        return h;
    }

    /**
     * @return true if this address is equal to the provided object
     * @see Object#equals(Object)
     */
    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        // getClass() method 会返回这个class的Name，如果两者都不是同一个class那直接return false
        // 只要new了一个Q5Address，那this就不可能为null（可以理解为对象已产生），因为new了之后才能使用
        // Q5Address的equals去比较（即先new了才能用本method）
        else if (object == null || getClass() != object.getClass()) return false;
        else if (hashCode() != object.hashCode()) return false;
        Q5Address q5Address = (Q5Address) object;
        //
        return Objects.equals(streetName,q5Address.streetName) &&
                streetNumber == q5Address.streetNumber &&
                postCode == q5Address.postCode;
        // FIXME complete this method
    }

    @Override
    public String toString() {
        return streetNumber + " " + streetName + " " + postCode;
    }

    // DO NOT DELETE OR CALL THIS METHOD
    int passThroughHash() {
        return super.hashCode();
    }
}
