package comp1110.exam;

import java.util.*;

/**
 * COMP1110 Final Exam, Question 1.3 (harder)
 *
 * 5 Marks
 */
public class Q1Number {
  /**
   * This question is about a number finding puzzle.
   *
   * You will be given a square grid of numbers, represented as a single
   * array of integers.   Each value in the grid is a number between 0 and 9.
   * You will also be given a target number.   Your task is to try to find
   * the target number within the grid.  If you find it, you return the
   * index of the grid element holding the first digit of the number.  If
   * you can't find it, return -1.
   *
   * Numbers can be 'hidden' in the grid by consecutive digits being in
   * horizontally or vertically adjacent elements (but not diagonally).
   * When creating numbers, digits in the grid may only be used ONCE.
   *
   * For example, given the 3 x 3 grid [2, 4, 4, 0, 5, 7, 7, 1, 4] and the
   * target 42, you would return 1.   Visualizing the grid:
   *
   *    2 4 4
   *    0 5 7
   *    7 1 4
   *
   *    2 4 _
   *    _ _ _
   *    _ _ _
   *
   * The number 42 is 'hidden' in the first two elements of the grid, starting
   * at offset 1 then going left, so the answer is 1.
   *
   * Given the 6 x 6 grid [0, 8, 0, 9, 1, 1, 6, 7, 6, 3, 2, 9, 2, 7, 7, 9, 2, 8, 4, 0, 9, 2, 9, 2, 0, 5, 1, 1, 5, 9, 8, 5, 7, 1, 1, 7],
   * and the target 91507, you would return 20.  Visualizing the grid:
   *
   *  0 8 0 9 1 1
   *  6 7 6 3 2 9
   *  2 7 7 9 2 8
   *  4 0 9 2 9 2
   *  0 5 1 1 5 9
   *  8 5 7 1 1 7
   *
   *  _ _ _ _ _ _
   *  _ _ _ _ _ _
   *  _ 7 _ _ _ _
   *  _ 0 9 _ _ _
   *  _ 5 1 _ _ _
   *  _ _ _ _ _ _
   *
   *  The number 91507 is 'hidden' in the grid starting at location 20,
   *  then going down, then left, then up twice.
   *
   * @param grid An array of integers between 0 and 9, where the size of the
   *             array is square (1, 4, 9, 16 etc).
   * @param target A target number which may be hidden in the grid.
   * @return If the target number is hidden in the grid, return the location
   * (index) within the grid of the first digit of the target number, or -1
   * if it is not in the grid.
   */
  public static int find(int[] grid, int target) {
    // 使用 DFS均可，时间复杂度为O(V+E)
    // 这里使用DFS, BFS无法满足题目要求。

    //将target数字拆解成一个个的，例如97574将被拆解为 targetArr = {9,7,5,7,4}
    String targetStr = String.valueOf(target);
    int[] targetArr = new int[targetStr.length()];
    for (int i = 0;i< targetArr.length;i++)
      targetArr[i] = Integer.parseInt(targetStr.substring(i,i+1));
    ArrayList<Integer> visitedPos = new ArrayList<>();
    //使用FIFO的Queue队列存储状态
    Stack<Integer> S = new Stack<>();
    int firstPos = -1;
    for (int i = 0; i < grid.length; i ++){
        if (targetArr[0] == grid[i]){
          firstPos = i;
          S.push(i); //初始的位置
        }
    }
    if (firstPos == -1) return -1;
    int currentTargetIndex = 0;
    while(!S.isEmpty()){
      int currentPos = S.pop();
      Set<Integer> successPos = successors(grid,currentPos,visitedPos,grid[currentTargetIndex]).keySet();
      for (Integer pos: successPos){

      }
    }


    return currentTargetIndex == targetArr.length-1 ? firstPos : -1;
    // FIXME complete this method
  }





  public static HashMap<Integer,Integer> successors(int[] grid, int pos, List<Integer> visited, int currentVal){
    int y = grid.length;
    int x = (int) Math.sqrt(y);
    HashMap<Integer,Integer> rtn = new HashMap<>();
    try{
      if (currentVal == grid[pos-1]) rtn.put(pos-1,grid[pos-1]);
    } catch (Exception e){

    }
    try{
      if (currentVal == grid[pos+1]) rtn.put(pos+1,grid[pos+1]);
    } catch (Exception e){

    }
    try {
      if (currentVal == grid[pos-x]) rtn.put(pos-x,grid[pos-x]);
    } catch (Exception e){

    }
    try {
      if (currentVal == grid[pos+x]) rtn.put(pos+x,grid[pos+x]);
    } catch (Exception e){

    }
    for (Integer i : visited){
        rtn.remove(i);
    }
    return rtn;
  }

  public boolean goal_test(int[] grid, int target){
    return false;
  }
}
