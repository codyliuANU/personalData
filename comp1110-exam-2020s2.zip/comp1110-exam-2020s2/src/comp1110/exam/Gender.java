package comp1110.exam;

public enum Gender {
    male,female;
}
