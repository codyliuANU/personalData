package comp1110.exam;

/**
 * COMP1110 Final Exam, Question 1.1
 *
 * 5 Marks
 */
public class Q1Closest {
    /**
     * Given an array of integers and a special value target,
     * return the value in the array that is numerically closest to
     * target. If the array contains two different values equally
     * close to target, return the smaller value.  If the array is
     * empty, return Integer.MAX_VALUE.
     *
     * @param in    An array of integers
     * @param target a target value to search for in the array
     * @return the value in the array that is numerically closest to
     * target, returning the lesser of equally close values, and
     * returning Integer.MAX_VALUE if the array
     * has no entries.
     */
    public static int findClosest(int[] in, int target) {
        /*
        考点一：int和Integer的区别？
        Integer是int的包装类，int rtn出来的只是一个值，而Integer需要new 实例化出来
        例如
        Integer i = new Integer(100);
        Integer j = new Integer(100);
        i和j是不等的，因为i和j仅仅是Integer class当中的value值相同，而Integer class里并没有重写equal method。
        实际上i和j对比的是各自的内存地址（此情况适用所有没有写equal method的class）
        但是如果
        int i = 100
        Integer j = new Integer(100);
        这里i == j会返回为true，因为Java会把int i自动包装为Integer j进行对比。

        更多的关于int 和Integer的说明请看
        https://comp.anu.edu.au/courses/comp1110/lectures/pdf/J10.pdf
        https://wenku.baidu.com/view/5cebf11413661ed9ad51f01dc281e53a580251b6.html
        */

        // FIXME complete this method
        int rtn = Integer.MAX_VALUE;
        int currentDiff = Integer.MAX_VALUE;

        for (int i = 0; i < in.length; i++){
            if (Math.abs(in[i] - target) < currentDiff){
                currentDiff = Math.abs(in[i] - target);
                rtn = in[i];

            }
            else if (Math.abs(in[i] - target) == currentDiff){
                if (in[i] < rtn) rtn = in[i];
            }
        }
        return rtn;
    }
}
